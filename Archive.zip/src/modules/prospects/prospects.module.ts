import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  ProspectsController,
  ProspectsPublicController,
} from './prospects.controller';
import { ProspectsService } from './prospects.service';
import { Prospect, ProspectSchema } from './prospect.schema';
import { MailModule } from '../mail/mail.module';
import { SiteModule } from '../site/site.module';

@Module({
  imports: [
    SiteModule,
    MongooseModule.forFeature([
      { name: Prospect.name, schema: ProspectSchema },
    ]),
    MailModule,
  ],
  controllers: [ProspectsController, ProspectsPublicController],
  providers: [ProspectsService],
  exports: [ProspectsService],
})
export class ProspectsModule {}
